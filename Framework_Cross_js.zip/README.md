# Cross.js
Framework Cross.js.

 Cross.js progressive Framework.
 
#### *cmd:*
<ol>
   <li>Запуск.</li>
   <li>Отправка сообщений в консоль.</li>
   <li>Открытие терминала.</li>
   <li>Конфигурация.</li>
</ol>

#### *Есть:*
<ol>
   <li>создание компонентов.</li>
   <li>создание динамичныx input</li>
</ol>

#### все cmd: 
```javascript
Cross.launch();
Cross.configuration();
Cross.message();
Cross.config();
Cross.printLine();

// Canvas
new Application();
Application.start();
Application.drawLine();
Application.BoxGeometry();
Application.end();
 
// Components
Component.createComponents();

// Frontend
CreateFrontend.createInput();
CreateFrontend.createTemplate();

// Ajax
HTTP.File();
HTTP.send();
HTTP.shifr();

new Terminal(); // beta-version production
```

#### *CSS class:*
```css
// input
to-cross-input-info
to-cross-input-success
```


####  begin structure Cross.js 

```javascript
// импортируем ядро фреймворка 📤
import { Cross } from './Cross.js'; 
Cross.message('container');
Cross.config();
// пример изменения цвета body
Cross.configuration('window',
'bgdocolor', 'skyblue');
// теперь попробуем изменить цвет текста
Cross.configuration('window','color','red');
// напечатаем на экран текст
Cross.printLine('Hello Cross.js!');
```

##  Приемры Ajax запросов.

*простой пример:*
```javascript
// импортируем все для Ajax запросов 📤
import { HTTP } from '/Framework_Cross/HTTPCross/HTTPCross.js';
// пишем метод запроса и файл
HTTP.File('GET','index.html');
//можно что то отправить(сообщение📝) 📨
HTTP.send('container AJAX to Cross.js');
```

*средний пример:*
```javascript
// импортируем все для Ajax запросов 📤
import { HTTP } from '/Framework_Cross/HTTPCross/HTTPCross.js';
// пишем метод запроса и файл
let name = 'Фреймворк';
HTTP.File('GET','index.html');
  //т.е. кодирование с помощью метода encodeURIComponent
name = 'BD:' + encodeURIComponent(name);
/*
Устанавливаем заголовок Content-Type(обязательно для метода POST). Он предназначен для указания кодировки, с помощью которой зашифрован запрос. Это необходимо для того, чтобы сервер знал как его раскодировать. Тут шифр вместо setRequestHeader().
*/
HTTP.shifr('Content-Type','application/x-www-form-urlencoded');
HTTP.send(name);
```


*Средний пример без коментариев:*
```javascript
import { HTTP } from '/Framework_Cross/ HTTPCross/HTTPCross.js';
let name = 'Фреймворк';
HTTP.File('GET','index.html'); 
name = 'BD:' + encodeURIComponent(name);
HTTP.shifr('Content-Type','application/x-www-form-urlencoded');
HTTP.send(name);
```

## *Import box 📦*

```javascript
//  ядро фреймворка 📤
import { Cross } from './Cross.js'; 
//  все для Ajax запросов 📤
import { HTTP } from '/Framework_Cross/ HTTPCross/HTTPCross.js';
// импортируем терминал для cmd 📤
import { Terminal } from './Cross.js';
// это полный  импорт для фронтендера 📤
import * as CreateFrontend          from './Framework_Cross/CreateFrontend/createInput.js'; 
//импортируем для создания компонентов 📤
import * as Component from './Framework_Cross/Components/CrossComponents.js';
// Canvas 📤
import {  Application } from './Framework_Cross/CrossApplication/CrossCanvas.js';
```

#### *Настройка*


#### *Описание:* 
*Мощный фреймворк, на нем можно делать простые AJAX запросы!*

## Installation
Install dependencies.
```npm
npm install
```
___

## Contributors
*Original Author: [E5war5IT](https://github.com/E5war5IT)*

___

## Copyright:
***2021-2022***

___