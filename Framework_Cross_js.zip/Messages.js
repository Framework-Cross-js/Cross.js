/**
 *
 * <p style="color: #95EFFE" >Documentation</p>
 * 
 *<a href="https://github.com">GitHub</a>
 * 
 * <p style="color: darkorange" >Original Author: E5war5IT</p>
 * <a style="color: darkorange;" href="https://github.com/E5war5IT">Github Author</a>
 
 * 
 * <p style="color: darkorange; text-align: right; margin-left: 20pt" >2022г.</p>
 * 
 * @param {string} title - Название документации.
 * @param {string} author - Автор документации.
 */
function Book(title, author) {
  this.title = title;
  this.author = author;
}

new Book()