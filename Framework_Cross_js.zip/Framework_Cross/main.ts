let str: any = 'Текстовая переменная'
let strLength = (<string>str).length
console.warn(strLength, str);